-- AlterTable
ALTER TABLE "AsfiFundTransfer" ADD COLUMN     "spreadsheetFilename" TEXT;

-- AlterTable
ALTER TABLE "AsfiRequest" ADD COLUMN     "spreadsheetFilename" TEXT;
